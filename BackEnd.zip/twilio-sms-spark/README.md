# twilio-sms-spark
A Java mobile backend using the Spark framework and Twilio to send SMS messages

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy?template=https://github.com/mplacona/twilio-sms-spark)

![Running the Project](https://github.com/mplacona/twilio-sms-spark/blob/master/running-project.gif)
